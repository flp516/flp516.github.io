#!/usr/bin/env python3
"""
每日科技新闻语音播报流水线（通过 CLI 调用 TTS）
1. 抓取科技新闻
2. 整理成口语化播报文稿
3. 分批调用 tts.py 合成语音
4. 拼接 MP3 → 输出路径
"""

import subprocess
import sys
import os
import re
import time
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TTS_SCRIPT = os.path.normpath(os.path.join(SCRIPT_DIR, "..", "..", "xiaoyi-tts", "scripts", "tts.py"))
OUTPUT_DIR = "/home/sandbox/tts_output"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def fetch_news():
    """运行 broadcast.py 获取新闻"""
    result = subprocess.run(
        [sys.executable, os.path.join(SCRIPT_DIR, "broadcast.py")],
        capture_output=True, text=True, timeout=30
    )
    if result.returncode != 0:
        print(f"❌ 新闻抓取失败: {result.stderr}", file=sys.stderr)
        return None
    return result.stdout


def parse_news(raw_text):
    """从简报文本中提取新闻标题列表"""
    lines = raw_text.strip().split("\n")
    headlines = []
    for line in lines:
        line = line.strip()
        m = re.match(r"\d+\.\s+\*\*(.+?)\*\*", line)
        if m:
            headlines.append(m.group(1))
    return headlines


def build_spoken_script(headlines):
    """整理成口语播报文稿"""
    today = datetime.now().strftime("%Y年%m月%d日")
    lines = [f"早上好，今天是{today}，欢迎收听每日科技播报。"]
    for i, title in enumerate(headlines, 1):
        lines.append(f"第{i}条：{title}")
    lines.append("以上就是今天的全部内容，感谢收听，祝您一天好心情！")
    return "\n".join(lines)


def split_into_chunks(text, max_chars=480):
    """按段落拆分，每段不超过 max_chars 字符"""
    paragraphs = text.split("\n")
    chunks = []
    current = ""
    for p in paragraphs:
        candidate = current + ("\n" if current else "") + p
        if len(candidate.replace("\n", "")) > max_chars and current:
            chunks.append(current)
            current = p
        else:
            current = candidate
    if current:
        chunks.append(current)
    return chunks


def tts_cli(text, speed="5.0"):
    """通过 CLI 调用 tts.py 合成语音，返回输出中的文件路径"""
    # tts.py 将文件保存在当前工作目录
    workdir = os.path.dirname(TTS_SCRIPT)
    result = subprocess.run(
        [sys.executable, TTS_SCRIPT,
         "--language", "zh-Hans",
         "--person", "zh-Hans-st-1",
         "--text", text,
         "--speed", speed,
         "--volume", "5.0",
         "--pitch", "5.0"],
        capture_output=True, text=True, timeout=60,
        cwd=workdir
    )
    if result.returncode != 0:
        print(f"❌ TTS CLI 失败: {result.stderr}", file=sys.stderr)
        return None

    # 从输出中提取 "✅ 纯音频已保存到：xxx.mp3"
    output = result.stdout + result.stderr
    m = re.search(r"纯音频已保存到[：:]\s*(.+?\.mp3)", output)
    if m:
        path = m.group(1).strip()
        # 如果是相对路径，转为绝对
        if not os.path.isabs(path):
            path = os.path.join(workdir, path)
        if os.path.exists(path):
            return path
    print(f"⚠️  未从TTS输出中找到文件路径", file=sys.stderr)
    print(f"stdout: {result.stdout[:200]}", file=sys.stderr)
    print(f"stderr: {result.stderr[:200]}", file=sys.stderr)
    return None


def concat_mp3(mp3_paths, output_path):
    """简单二进制拼接 MP3"""
    with open(output_path, "wb") as out:
        for p in mp3_paths:
            with open(p, "rb") as f:
                out.write(f.read())
    return output_path


def main():
    print("📡 正在抓取今日科技新闻...", file=sys.stderr)
    raw = fetch_news()
    if not raw:
        print("ERROR: 新闻抓取失败")
        sys.exit(1)

    headlines = parse_news(raw)
    if not headlines:
        print("ERROR: 未能解析新闻标题")
        sys.exit(1)

    print(f"✅ 获取到 {len(headlines)} 条新闻", file=sys.stderr)

    script = build_spoken_script(headlines)
    total_chars = len(script.replace("\n", ""))
    print(f"📝 文稿共 {total_chars} 字", file=sys.stderr)

    chunks = split_into_chunks(script)
    print(f"🔀 将分 {len(chunks)} 段合成（每段≤480字）", file=sys.stderr)

    # 输出文稿预览
    for idx, chunk in enumerate(chunks):
        print(f"--- 段 {idx+1} ({len(chunk.replace(chunk,''))}字) ---", file=sys.stderr)
        print(chunk[:100], "..." if len(chunk)>100 else "", file=sys.stderr)

    audio_files = []
    for idx, chunk in enumerate(chunks):
        cchars = len(chunk.replace("\n", ""))
        print(f"🔊 合成第 {idx+1}/{len(chunks)} 段（{cchars}字）...", file=sys.stderr)
        fpath = tts_cli(chunk)
        if not fpath:
            print(f"❌ 第{idx+1}段合成失败，跳过", file=sys.stderr)
            continue
        print(f"   ✅ 保存到 {fpath}", file=sys.stderr)
        audio_files.append(fpath)
        time.sleep(0.3)

    if not audio_files:
        print("ERROR: 所有段落合成失败", file=sys.stderr)
        print(f"\n--- 文字版播报 ---\n{script}\n---")
        sys.exit(1)

    # 拼接
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    final_path = os.path.join(OUTPUT_DIR, f"daily_tech_broadcast_{ts}.mp3")
    os.makedirs(os.path.dirname(final_path), exist_ok=True)

    if len(audio_files) == 1:
        import shutil
        shutil.copy(audio_files[0], final_path)
    else:
        concat_mp3(audio_files, final_path)

    # 估算时长（16kbps CBR MP3，粗略 1KB→0.5s）
    size_kb = os.path.getsize(final_path) / 1024
    est_seconds = int(size_kb / 2)

    # 清理分散的临时文件
    if len(audio_files) > 1:
        for f in audio_files:
            try:
                os.remove(f)
            except OSError:
                pass

    print(f"\n✅ 播报完成")
    print(f"AUDIO_PATH:{final_path}")
    print(f"ESTIMATED_SEC:{est_seconds}")
    print(f"NEWS_COUNT:{len(headlines)}")


if __name__ == "__main__":
    main()
