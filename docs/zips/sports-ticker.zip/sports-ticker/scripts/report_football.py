#!/usr/bin/env python3
"""足球战报告-查询各联赛赛况，输出简洁中文摘要"""
import urllib.request, json, sys
from datetime import datetime, timezone

BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer"
UA = {"User-Agent": "Mozilla/5.0"}

LEAGUES = [
    ("eng.1", "🏴󠁧󠁢󠁥󠁮󠁧󠁿 英超"),
    ("esp.1", "🇪🇸 西甲"),
    ("ita.1", "🇮🇹 意甲"),
    ("ger.1", "🇩🇪 德甲"),
    ("fra.1", "🇫🇷 法甲"),
    ("uefa.europa", "🌍 欧联"),
]

def fetch_scoreboard(league):
    url = f"{BASE}/{league}/scoreboard"
    req = urllib.request.Request(url, headers=UA)
    try:
        data = json.loads(urllib.request.urlopen(req, timeout=8).read())
        return data.get("events", [])
    except:
        return None

def format_events(events):
    """Format events into compact text. Returns list of lines."""
    lines = []
    for e in events:
        comp = e.get("competitions", [{}])[0]
        c = comp.get("competitors", [])
        if len(c) < 2:
            continue
        
        competitors = {}
        for x in c:
            side = x.get("homeAway", "away")
            competitors[side] = {
                "name": x.get("team", {}).get("displayName", "?"),
                "score": x.get("score", "0"),
                "id": x.get("team", {}).get("id", ""),
            }
        
        away, home = competitors.get("away", {}), competitors.get("home", {})
        status = comp.get("status", {}).get("type", {})
        st_type = status.get("name", "STATUS_SCHEDULED")
        st_desc = status.get("description", "待定")
        clock = status.get("displayClock", "")
        
        # Status icon
        if "IN_PROGRESS" in st_type:
            icon = "🔴 LIVE"
            time_str = f" {clock}'" if clock else ""
        elif "STATUS_FINAL" in st_type or "STATUS_FULL_TIME" in st_type:
            icon = "🏁"
            time_str = ""
        elif "STATUS_HALFTIME" in st_type:
            icon = "⏸️ 中场"
            time_str = ""
        elif "STATUS_SCHEDULED" in st_type or "STATUS_PRE" in st_type:
            icon = "📅"
            time_str = ""
        else:
            icon = st_desc
            time_str = ""
        
        line = f"{icon}{time_str} {away['name']} {away['score']} - {home['score']} {home['name']}"
        lines.append(line)
    return lines

def main():
    now = datetime.now(timezone.utc)
    output = [f"⚽ 足球战报 {now.strftime('%m/%d %H:%M')} (UTC)", ""]
    has_data = False
    
    for league_id, league_name in LEAGUES:
        events = fetch_scoreboard(league_id)
        if events is None:
            continue
        formatted = format_events(events)
        if formatted:
            has_data = True
            output.append(f"── {league_name} ──")
            for line in formatted:
                output.append(f"  {line}")
            output.append("")
    
    # Also try World Cup
    wc_events = fetch_scoreboard("fifa.world")
    if wc_events:
        formatted = format_events(wc_events)
        if formatted:
            output.insert(2, f"── 🌍 世界杯 ──")
            for i, line in enumerate(formatted):
                output.insert(3 + i, f"  {line}")
            output.insert(3 + len(formatted), "")
    
    if not has_data:
        output.append("📭 暂无进行中的比赛")
        output.append("下次检查时间: +30分钟")
    
    print("\n".join(output))

if __name__ == "__main__":
    main()
