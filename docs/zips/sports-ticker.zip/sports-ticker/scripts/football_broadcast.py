#!/usr/bin/env python3
"""
足球战报 + TTS语音播报脚本
定时执行：获取实时赛况 → 合成中文语音 → 发送给用户
"""
import urllib.request, json, sys, os, subprocess, time
from pathlib import Path
from datetime import datetime, timezone

BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer"
UA = {"User-Agent": "Mozilla/5.0"}
SKILL_DIR = Path(__file__).parent.parent
TTS_DIR = Path.home() / ".openclaw" / "workspace" / "skills" / "xiaoyi-tts"
TTS_OUTPUT = TTS_DIR

# 联赛配置：(league_id, 中文名)
LEAGUES = [
    ("eng.1", "英超"),
    ("esp.1", "西甲"),
    ("ita.1", "意甲"),
    ("ger.1", "德甲"),
    ("fra.1", "法甲"),
    ("fifa.world", "世界杯"),
    ("uefa.champions", "欧冠"),
]

# 热门队名英中对照（可扩展）
TEAM_CN = {
    "Real Madrid": "皇家马德里",
    "Barcelona": "巴塞罗那",
    "Atlético Madrid": "马德里竞技",
    "Manchester City": "曼彻斯特城",
    "Manchester United": "曼彻斯特联",
    "Liverpool": "利物浦",
    "Chelsea": "切尔西",
    "Arsenal": "阿森纳",
    "Tottenham Hotspur": "托特纳姆热刺",
    "Paris Saint-Germain": "巴黎圣日耳曼",
    "Bayern Munich": "拜仁慕尼黑",
    "Juventus": "尤文图斯",
    "AC Milan": "AC米兰",
    "Inter Milan": "国际米兰",
    "Internazionale": "国际米兰",
    "AS Roma": "罗马",
    "Napoli": "那不勒斯",
    "Fiorentina": "佛罗伦萨",
    "Ajax": "阿贾克斯",
    "PSV Eindhoven": "埃因霍温",
}

def to_cn(name):
    return TEAM_CN.get(name, name)

def fetch_scoreboard(league):
    url = f"{BASE}/{league}/scoreboard"
    req = urllib.request.Request(url, headers=UA)
    try:
        data = json.loads(urllib.request.urlopen(req, timeout=8).read())
        return data.get("events", [])
    except:
        return None

def get_broadcast_text():
    """生成中文播报文本（供TTS使用）"""
    now = datetime.now(timezone.utc)
    text_parts = [f"足球战报，{now.strftime('%m月%d日')}，北京时间"]

    for league_id, league_cn in LEAGUES:
        events = fetch_scoreboard(league_id)
        if not events:
            continue
        league_matches = []
        for e in events:
            comp = e.get("competitions", [{}])[0]
            cs = comp.get("competitors", [])
            if len(cs) < 2:
                continue
            away = next((x.get("team",{}).get("displayName","?") for x in cs if x.get("homeAway")=="away"),"?")
            home = next((x.get("team",{}).get("displayName","?") for x in cs if x.get("homeAway")=="home"),"?")
            a_s = next((x.get("score","0") for x in cs if x.get("homeAway")=="away"),"0")
            h_s = next((x.get("score","0") for x in cs if x.get("homeAway")=="home"),"0")
            status = comp.get("status",{}).get("type",{}).get("description","")
            st_type = comp.get("status",{}).get("type",{}).get("name","")
            clock = comp.get("status",{}).get("displayClock","0")

            # 将英文队名转中文
            away_cn = to_cn(away)
            home_cn = to_cn(home)

            if "IN_PROGRESS" in st_type:
                match_str = f"{away_cn} {a_s}比{h_s} {home_cn}，比赛进行中，第{clock}分钟"
            elif "FULL_TIME" in st_type or "FINAL" in st_type:
                match_str = f"{away_cn} {a_s}比{h_s} {home_cn}，比赛结束"
            elif "HALFTIME" in st_type:
                match_str = f"{away_cn} {a_s}比{h_s} {home_cn}，中场休息"
            else:
                match_str = f"{away_cn}对阵{home_cn}，尚未开赛"
            league_matches.append(match_str)

        if league_matches:
            # 最多取2场，避免超500字
            selected = league_matches[:2]
            text_parts.append(f"{league_cn}方面，{'，'.join(selected)}")

    full_text = "，".join(text_parts)

    # 限制500字以内
    if len(full_text) > 480:
        full_text = full_text[:477] + "..."

    if full_text == "":
        full_text = "当前暂无足球赛事信息"

    return full_text

def get_written_report():
    """生成文字版推送（供消息展示）"""
    now = datetime.now(timezone.utc)
    lines = [f"⚽ 足球战报 | {now.strftime('%m/%d %H:%M')} (北京时间)", ""]

    has_data = False
    for league_id, league_cn in LEAGUES:
        events = fetch_scoreboard(league_id)
        if not events:
            continue
        league_lines = []
        for e in events:
            comp = e.get("competitions", [{}])[0]
            cs = comp.get("competitors", [])
            if len(cs) < 2:
                continue
            away = next((x.get("team",{}).get("displayName","?") for x in cs if x.get("homeAway")=="away"),"?")
            home = next((x.get("team",{}).get("displayName","?") for x in cs if x.get("homeAway")=="home"),"?")
            a_s = next((x.get("score","0") for x in cs if x.get("homeAway")=="away"),"0")
            h_s = next((x.get("score","0") for x in cs if x.get("homeAway")=="home"),"0")
            status = comp.get("status",{}).get("type",{}).get("description","Scheduled")
            clock = comp.get("status",{}).get("displayClock","")
            st_type = comp.get("status",{}).get("type",{}).get("name","")

            if "IN_PROGRESS" in st_type:
                icon = "🔴 LIVE"
                time_str = f" {clock}'"
            elif "FULL_TIME" in st_type or "FINAL" in st_type:
                icon = "🏁"
                time_str = ""
            elif "HALFTIME" in st_type:
                icon = "⏸️ 中场"
                time_str = ""
            elif "SCHEDULED" in st_type or "PRE" in st_type:
                icon = "📅"
                time_str = ""
            else:
                icon = status
                time_str = ""

            away_cn = to_cn(away)
            home_cn = to_cn(home)
            league_lines.append(f"  {icon}{time_str} {away_cn} {a_s} - {h_s} {home_cn}")

        if league_lines:
            has_data = True
            lines.append(f"── {league_cn} {''.join(['─'] * (20 - len(league_cn)))}")
            lines.extend(league_lines)
            lines.append("")

    if not has_data:
        lines.append("📭 暂无进行中的比赛\n")

    lines.append(f"📢 语音播报已同步生成")
    lines.append("⏰ 下次更新：+2小时")
    return "\n".join(lines)

def generate_tts(text):
    """调用xiaoyi-tts生成语音"""
    tts_script = TTS_DIR / "scripts" / "tts.py"
    if not tts_script.exists():
        return None

    cmd = [
        sys.executable, str(tts_script),
        "--language", "zh-Hans",
        "--person", "zh-Hans-st-1",
        "--text", text,
        "--speed", "5.0",
        "--volume", "6.0",
        "--pitch", "5.0",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=45, cwd=str(TTS_DIR))
    # 从输出中查找音频文件路径
    for line in result.stdout.split("\n"):
        if "纯音频已保存到" in line or "已保存到" in line:
            path = line.split("：")[-1].strip() if "：" in line else line.split(" ")[-1].strip()
            return path
        if ".mp3" in line:
            # 尝试从行中提取路径
            import re
            match = re.search(r'([/\w\.\-]+\.mp3)', line)
            if match:
                return match.group(1)
    return None

def main():
    print("=" * 40)
    print("⚽ 足球战报生成中...")
    print("=" * 40)

    # 1. 获取文字版报告
    report = get_written_report()
    print(report)
    print()

    # 2. 生成TTS播报文本
    broadcast_text = get_broadcast_text()
    print(f"🎙️ 播报文本 ({len(broadcast_text)}字):")
    print(f"  {broadcast_text}")
    print()

    # 3. 生成语音
    print("🎤 正在合成语音...")
    audio_path = generate_tts(broadcast_text)
    if audio_path:
        print(f"✅ 语音已生成: {audio_path}")
    else:
        print("⚠️ 语音合成失败或未找到输出文件")

    # 4. 输出JSON供agent消费
    result = {
        "text_report": report,
        "broadcast_text": broadcast_text,
        "audio_file": str(audio_path) if audio_path else None,
        "time": datetime.now().isoformat(),
    }
    print()
    print("---JSON_RESULT---")
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    main()
