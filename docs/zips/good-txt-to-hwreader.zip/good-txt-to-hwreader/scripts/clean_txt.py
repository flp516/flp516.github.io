#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TXT 电子书清理修复脚本
功能：编码检测、广告清理、乱码修复、排版规范化
"""

import re
import sys
import os
from pathlib import Path

# 尝试导入 chardet，如果没有则使用简单编码检测
try:
    import chardet
    HAS_CHARDET = True
except ImportError:
    HAS_CHARDET = False

# ==================== 配置 ====================

# 常见广告模式
AD_PATTERNS = [
    # 网站推广
    r'=====.*?(?:本书|本作品|章节).*?(?:首发|独家|由).*?(?:www\.|http|\.com|\.cn|\.net).*?=====',
    r'本书由.*?首发.*?',
    r'最新章节请访问.*?',
    r'更多精彩.*?请访问.*?',
    r'=====.*?广告.*?=====',
    r'=====.*?推广.*?=====',
    r'=====.*?章节广告.*?=====',
    # APP 推广
    r'下载.*?APP.*?(?:享受|体验|获得).*?',
    r'注册.*?送.*?(?:积分|红包|金币).*?',
    r'新手注册.*?送.*?',
    # 版权声明广告
    r'禁止转载.*?更多精彩.*?',
    # 其他常见广告
    r'\(本章未完，请翻页\)',
    r'\(未完待续.*?\)',
]

# 常见乱码映射
MOJIBAKE_MAP = {
    # GBK 解码为 UTF-8 时常见乱码
    '锟斤拷': '',
    '锟叫斤拷': '',
    '烫烫烫': '',
    '屯屯屯': '',
    # 常见错误字符
    '鈥': '"',
    '鈥': '"',
    '鈥': "'",
    '鈥': "'",
    '鈥': '...',
    '鈥': '-',
    '鈥': '——',
    # 其他常见乱码
    '銆': '',
    '銆': '',
    '銆': '',
}

# 章节标题模式
CHAPTER_PATTERNS = [
    r'^第[零一二三四五六七八九十百千万\d]+[章节回集卷部篇]',
    r'^[零一二三四五六七八九十百千万\d]+[、\.]',
    r'^Chapter\s*\d+',
    r'^CHAPTER\s*\d+',
    r'^卷[零一二三四五六七八九十\d]+',
    r'^序章|前言|引子|楔子',
    r'^尾声|后记|结局',
]

# ==================== 编码检测 ====================

def detect_encoding(file_path):
    """检测文件编码"""
    if HAS_CHARDET:
        with open(file_path, 'rb') as f:
            raw = f.read(100000)  # 读取前100KB
            result = chardet.detect(raw)
            return result['encoding']
    else:
        # 简单编码检测
        encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030', 'big5', 'utf-16']
        for enc in encodings:
            try:
                with open(file_path, 'r', encoding=enc) as f:
                    f.read(10000)
                return enc
            except:
                continue
        return 'utf-8'

def read_file(file_path):
    """读取文件，自动检测编码"""
    encoding = detect_encoding(file_path)
    try:
        with open(file_path, 'r', encoding=encoding, errors='replace') as f:
            content = f.read()
        return content, encoding
    except Exception as e:
        print(f"读取文件失败: {e}")
        return None, None

# ==================== 清理功能 ====================

def clean_ads(content):
    """清理广告"""
    removed_chars = 0
    ad_count = 0
    
    for pattern in AD_PATTERNS:
        matches = re.findall(pattern, content, re.IGNORECASE | re.MULTILINE)
        for match in matches:
            removed_chars += len(match)
            ad_count += 1
        content = re.sub(pattern, '', content, flags=re.IGNORECASE | re.MULTILINE)
    
    return content, removed_chars, ad_count

def fix_mojibake(content):
    """修复乱码"""
    fixed_chars = 0
    
    for wrong, right in MOJIBAKE_MAP.items():
        count = content.count(wrong)
        if count > 0:
            content = content.replace(wrong, right)
            fixed_chars += count * len(wrong)
    
    return content, fixed_chars

def normalize_format(content):
    """规范化排版"""
    original_len = len(content)
    
    # 统一换行符
    content = content.replace('\r\n', '\n').replace('\r', '\n')
    
    # 移除行首行尾空白
    lines = [line.strip() for line in content.split('\n')]
    
    # 合并多个空行为最多两个
    result = []
    empty_count = 0
    for line in lines:
        if line == '':
            empty_count += 1
            if empty_count <= 2:
                result.append(line)
        else:
            empty_count = 0
            result.append(line)
    
    content = '\n'.join(result)
    
    # 规范化章节标题（前后各加一个空行）
    for pattern in CHAPTER_PATTERNS:
        content = re.sub(
            rf'([^\n]*)({pattern}.*?)([^\n]*)',
            r'\n\2\3\n',
            content,
            flags=re.MULTILINE
        )
    
    # 移除开头和结尾的多余空行
    content = content.strip()
    
    removed = original_len - len(content)
    return content, removed

# ==================== 主函数 ====================

def clean_txt(input_path, output_path=None):
    """主清理函数"""
    input_path = Path(input_path)
    if not input_path.exists():
        print(f"错误: 文件不存在 - {input_path}")
        return None
    
    # 生成输出路径
    if output_path is None:
        output_path = input_path.parent / f"{input_path.stem}_清理版{input_path.suffix}"
    else:
        output_path = Path(output_path)
    
    # 读取文件
    print(f"正在读取文件: {input_path}")
    content, encoding = read_file(input_path)
    if content is None:
        return None
    
    original_len = len(content)
    print(f"检测到编码: {encoding}")
    print(f"原文长度: {original_len:,} 字符")
    
    # 清理广告
    print("\n[1/3] 清理广告...")
    content, ad_chars, ad_count = clean_ads(content)
    print(f"  - 移除 {ad_count} 处广告，共 {ad_chars} 字符")
    
    # 修复乱码
    print("[2/3] 修复乱码...")
    content, fixed_chars = fix_mojibake(content)
    print(f"  - 修复 {fixed_chars} 字符乱码")
    
    # 规范化排版
    print("[3/3] 规范化排版...")
    content, removed_lines = normalize_format(content)
    print(f"  - 移除多余空白 {removed_lines} 字符")
    
    # 写入文件
    final_len = len(content)
    total_removed = original_len - final_len
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"\n{'='*50}")
    print(f"清理完成！")
    print(f"{'='*50}")
    print(f"输出文件: {output_path}")
    print(f"\n| 项目 | 结果 |")
    print(f"|------|------|")
    print(f"| 原文长度 | {original_len:,} 字符 |")
    print(f"| 清理后长度 | {final_len:,} 字符 |")
    print(f"| 移除内容 | {total_removed} 字符 ({total_removed/original_len*100:.2f}%) |")
    print(f"| 广告清理 | {ad_chars} 字符 |")
    print(f"| 乱码修复 | {fixed_chars} 字符 |")
    print(f"| 多余空行 | {removed_lines} 字符 |")
    
    return output_path

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python clean_txt.py <输入文件> [输出文件]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    result = clean_txt(input_file, output_file)
    if result:
        sys.exit(0)
    else:
        sys.exit(1)
