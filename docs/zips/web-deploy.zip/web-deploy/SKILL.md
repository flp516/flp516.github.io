---
name: web-deploy
description: 部署网页应用到云服务器中。当用户需要部署网页应用时，使用本 Skill。
---

## 部署上线

> ⚠️ **部署前必须询问用户确认**，得到明确同意后再执行打包和部署操作。
> ⚠️ **部署前必须在 AipexBase 创建一个 BaaS 应用**。如果之前没有创建过 AipexBase BaaS 应用，我们需要首先创建一个不含任何表格的 BaaS 应用；如果之前创建过，忽略这一条。

### 创建 BaaS 应用（不含任何表格）

#### 配置文件说明

| 配置文件 | 位置 | 说明 |
|---------|------|------|
| **全局配置** `config.json` | 本 skill(`web-deploy/`) 目录下 | 包含 `baseUrl` 和 `manageToken`，可以用该文件中的默认 `baseUrl` 和 `manageToken` |
| **项目配置** `baas-config.json` | 项目目录下 | 新建应用时从全局配置复制，批量创建后添加 `apiKey` 和 `appId`；迭代开发时直接使用 |

检查项目目录下的 `baas-config.json`：

- **不存在或缺少 `apiKey`** → 新建应用
- **存在且包含 `apiKey`** → 迭代开发

#### 初始化步骤

**步骤 1：检查并初始化全局配置**

读取 `<skill目录>/config.json`，检查 `baseUrl` 和 `manageToken` 是否已配置。

**步骤 2：复制配置到项目**

```bash
cd <项目目录>
cp <当前skill目录>/config.json ./baas-config.json
```

#### 新建应用流程

假如你只想创建一个空 BaaS 应用（不含任何表格），你可以使用下面的方法进行创建：

```bash
curl -X POST '<baseUrl>/api/manage/application' \
  -H 'Content-Type: application/json' \
  -H 'X-Manage-Token: <manageToken>' \
  -d '{
  "name": "应用名称",
  "userId": "10000"
}'
```

注：
- `userId`：固定参数，写死 `10000`
- 需要从 `baas-config.json` 中读取 `baseUrl` 和 `manageToken`

#### 更新 baas-config.json

BaaS 应用创建成功后，使用 Edit 工具添加返回的 `apiKey` 和 `appId`。

### 打包策略

根据项目类型选择对应的打包方式：

**纯 HTML 项目（无构建步骤）**：

```bash
cd <项目目录>
zip -r project.zip . -x "node_modules/*" -x ".git/*" -x "*.zip"
```

**Vue/React 等需要构建的项目**：

```bash
cd <项目目录>
# 1. 执行构建
npm run build  # 或 yarn build

cd dist   # 或 cd build
zip -r ../project.zip .
```

### 执行部署

**cURL 示例**：

```bash
curl -X POST '<baseUrl>/common/deploy?appId=<appId>' \
  -H 'code_flying: <apiKey>' \
  -F 'file=@./project.zip'
```

**注意**：此接口使用 `apiKey` 进行认证。`apiKey`、`appId`、`baseUrl` 需要从项目目录中的 `baas-config.json` 中获取。

部署成功后返回：

```json
{
  "code": 0,
  "data": {
    "url": "<部署 URL>"
  },
  "message": "ok",
  "success": true
}
```

### 输出
部署后的 URL 展示给用户。